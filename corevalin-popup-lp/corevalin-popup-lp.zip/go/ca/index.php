<?php $GEO = 'ca'; require __DIR__ . '/../go.php';
