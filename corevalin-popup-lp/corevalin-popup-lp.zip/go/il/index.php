<?php $GEO = 'il'; require __DIR__ . '/../go.php';
