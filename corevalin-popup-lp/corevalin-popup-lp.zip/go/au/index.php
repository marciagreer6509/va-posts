<?php $GEO = 'au'; require __DIR__ . '/../go.php';
