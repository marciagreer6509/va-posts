// Corevalin popup landers: static pages + /go/<geo> redirect. Blitz links live ONLY here.
const LINK = {
  au: 'https://trk2success.com/?a=2397&c=11249&s1=corevalinau&s2=gadspop',
  ca: 'https://trk2success.com/?a=2397&c=11248&s1=corevalinca&s2=gadspop',
  il: 'https://trk2success.com/?a=2397&c=11363&s1=corevalinil&s2=gadspop',
};
// Server / datacentre networks with 0 sales in 30 d of click logs (bot-block-list, 07 Oct)
const BAD_ASN = new Set([209366,132203,16509,14618,24940,396982,18779,16276,8075,46261,45102,47007,23033,62240,55990,203861,50300,202422,20473,199524,36007,58061,62563,63023,45090]);
const GOOD_BOT = /(AdsBot-Google|Googlebot|Google-Ads|Mediapartners-Google|Google-InspectionTool)/i;
const BAD_UA = /(curl|wget|python|httpclient|okhttp|go-http|java\/|headless|phantom|scrapy|semrush|ahrefs|mj12|dotbot|petalbot|bytespider|bot\b|crawler|spider)/i;
const MAX_PER_HOUR = 4; // clicks to /go/ per IP per hour before we stop sending them on
const HDR = { 'Cache-Control': 'no-store', 'X-Robots-Tag': 'noindex, nofollow' };

async function overLimit(ip) {
  const cache = caches.default;
  const key = new Request('https://rl.internal/' + encodeURIComponent(ip));
  const hit = await cache.match(key);
  const n = hit ? parseInt(await hit.text(), 10) + 1 : 1;
  await cache.put(key, new Response(String(n), { headers: { 'Cache-Control': 'max-age=3600' } }));
  return n > MAX_PER_HOUR;
}

export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);
    const m = url.pathname.match(/^\/go\/(au|ca|il)\/?$/);
    if (!m) return env.ASSETS.fetch(req);
    const geo = m[1];
    const home = new URL(geo === 'au' ? '/' : `/${geo}/`, url.origin).toString();
    const back = () => new Response(null, { status: 302, headers: { ...HDR, Location: home } });
    const ua = req.headers.get('user-agent') || '';
    const ip = req.headers.get('cf-connecting-ip') || '';
    const asn = req.cf && req.cf.asn;
    const googleBot = GOOD_BOT.test(ua);
    if (!googleBot) {
      if (!ua || BAD_UA.test(ua) || BAD_ASN.has(asn)) return back();
      if (ip && await overLimit(ip)) return back();
    }
    const dest = new URL(LINK[geo]);
    const cid = (url.searchParams.get('cid') || '').replace(/[^\w.\-:]/g, '').slice(0, 200);
    if (cid) dest.searchParams.set('s3', cid);
    return new Response(null, { status: 302, headers: { ...HDR, Location: dest.toString(), 'Referrer-Policy': 'no-referrer' } });
  },
};
