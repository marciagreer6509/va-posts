Upload each folder to your domain as-is: yourdomain.com/1/ ... /10/

/1/  = LS · section 1 · story
/2/  = LS · section 2 · noise
/3/  = LS · section 3 · mark
/4/  = LS · section 4 · twice
/5/  = LS · section 5 · questions
/6/  = No-LS · section 1 · story-nols
/7/  = No-LS · section 2 · noise-nols
/8/  = No-LS · section 3 · mark-nols
/9/  = No-LS · section 4 · twice-nols
/10/  = No-LS · section 5 · questions-nols
