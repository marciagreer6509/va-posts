/* =====================================================================
   THE ONLY FILE YOU EDIT.
   Paste a link between the "quotes" and save. All 5 pages use it.
   ===================================================================== */

/* PRODUCT A: your tracking link.
   End it with the sub-id field (like s2=) and the page name is added there,
   so your report shows which page sent the click (lp1garage ... lp5questions). */
var PRODUCT_A = "https://trk0y7c.com/c?p=P4016&o=O7936&cr=13048&s2=";

/* PRODUCT B: a second product. Leave it "" and every click goes to A. */
var PRODUCT_B = "";

/* SPLIT: % of visitors sent to product A when B is filled in. 50 = half / half.
   A visitor always keeps the same product. */
var SPLIT_A = 50;

/* OPTIONAL: lock pages to one product (page numbers, comma separated). These ignore the split. */
var ONLY_A_PAGES = "";
var ONLY_B_PAGES = "";

/* OPTIONAL: also send the Meta ad name (utm_content) to your report.
   Write the name of a free sub-id field of your link, for example s3. Leave "" = off. */
var AD_NAME_FIELD = "";
