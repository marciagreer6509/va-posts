<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:sm="http://www.sitemaps.org/schemas/sitemap/0.9">
<xsl:output method="html" encoding="UTF-8" indent="yes"/>
<xsl:template match="/">
<html lang="en"><head><meta charset="utf-8"/><title>Sitemap · GLP5 GLT</title>
<style>body{font-family:Alata,Arial,sans-serif;background:#F7FAF5;color:#10281D;margin:0;padding:32px}h1{font-family:Fraunces,Georgia,serif;color:#0C6B4A}
.smap{max-width:900px;margin:0 auto;background:#fff;border:1.5px solid #0C6B4A;border-radius:22px;padding:28px 34px}
table{border-collapse:collapse;width:100%}th,td{text-align:left;padding:9px 10px;border-bottom:1px solid #E3EAE4}th{color:#0C6B4A}a{color:#0C6B4A}</style></head>
<body><div class="smap"><h1>GLP5 GLT · sitemap</h1><p>Pages of glp5-glt.store listed for search engines.</p>
<table><tr><th>URL</th><th>Updated</th><th>Frequency</th><th>Priority</th></tr>
<xsl:for-each select="sm:urlset/sm:url"><tr><td><a href="{sm:loc}"><xsl:value-of select="sm:loc"/></a></td><td><xsl:value-of select="sm:lastmod"/></td><td><xsl:value-of select="sm:changefreq"/></td><td><xsl:value-of select="sm:priority"/></td></tr></xsl:for-each>
</table></div></body></html>
</xsl:template></xsl:stylesheet>
